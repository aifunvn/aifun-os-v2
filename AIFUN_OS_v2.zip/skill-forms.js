/**
 * AIFUN OS v2 — skill-forms.js
 * Định nghĩa 6 skills: fields + buildTitle() + buildPrompt()
 * Load sau config.js, trước skill-engine.js
 */

const SKILL_FORMS = {

  // ── SK-001: SOP Builder ────────────────────────────────────────────────────
  'sop-builder': {
    skillId:       'sop-builder',
    title:         'SOP Builder',
    icon:          '📄',
    category:      'Operations',
    color:         '#3B82F6',
    desc:          'Tạo SOP chuẩn hoàn chỉnh với checklist, KPI và phân công vai trò.',
    estimatedTime: '~2 phút',
    outputType:    'SOP Document',

    fields: [
      {
        id: 'sopName', label: 'Tên SOP *', type: 'text',
        placeholder: 'VD: Quy trình onboard khách hàng mới',
        required: true, span: 2
      },
      {
        id: 'department', label: 'Phòng ban *', type: 'text',
        placeholder: 'VD: Sales, Marketing, Vận hành...',
        required: true
      },
      {
        id: 'executor', label: 'Người thực hiện *', type: 'text',
        placeholder: 'VD: Nhân viên sales, Quản lý cấp trung...',
        required: true
      },
      {
        id: 'objective', label: 'Mục tiêu quy trình *', type: 'textarea',
        placeholder: 'Quy trình này giúp gì? Kết quả mong muốn là gì?',
        required: true, span: 2, rows: 3
      },
      {
        id: 'currentProcess', label: 'Quy trình hiện tại (nếu có)', type: 'textarea',
        placeholder: 'Mô tả ngắn cách đang làm — AI sẽ cải thiện...',
        required: false, span: 2, rows: 2
      },
      {
        id: 'frequency', label: 'Tần suất thực hiện', type: 'select',
        options: ['Hàng ngày', 'Hàng tuần', 'Hàng tháng', 'Theo yêu cầu', 'Một lần'],
        required: false
      },
      {
        id: 'kpiTarget', label: 'KPI mục tiêu', type: 'text',
        placeholder: 'VD: Xử lý trong 24h, tỷ lệ lỗi < 5%...',
        required: false
      },
    ],

    aiOutputSections: ['Mục đích & Phạm vi', 'Vai trò & Trách nhiệm', 'Quy trình từng bước', 'Checklist kiểm tra', 'KPI & Đánh giá'],

    buildTitle(fd) {
      const d    = new Date().toLocaleDateString('vi-VN').replace(/\//g, '');
      const name = (fd.sopName || 'SOP').substring(0, 30).replace(/\s+/g, '_');
      return `SOP_${name}_${d}`;
    },

    buildPrompt(fd) {
      return `Bạn là chuyên gia vận hành và chuẩn hóa quy trình doanh nghiệp của AIFUN — AI Optimal Solution.

Hãy tạo SOP (Standard Operating Procedure) hoàn chỉnh, chuyên nghiệp, có thể triển khai ngay cho doanh nghiệp SME Việt Nam.

THÔNG TIN ĐẦU VÀO:
- Tên SOP: ${fd.sopName || ''}
- Phòng ban: ${fd.department || ''}
- Người thực hiện: ${fd.executor || ''}
- Mục tiêu quy trình: ${fd.objective || ''}
- Quy trình hiện tại: ${fd.currentProcess || 'Chưa có quy trình chuẩn'}
- Tần suất: ${fd.frequency || 'Theo yêu cầu'}
- KPI mục tiêu: ${fd.kpiTarget || 'Chưa xác định'}

YÊU CẦU OUTPUT — đầy đủ các phần sau:

# ${fd.sopName || 'SOP'}
Phiên bản: 1.0 | Ngày tạo: ${new Date().toLocaleDateString('vi-VN')} | Phòng ban: ${fd.department || ''} | Trạng thái: Hiệu lực

## 1. MỤC ĐÍCH
Giải thích tại sao SOP này tồn tại, vấn đề gì được giải quyết.

## 2. PHẠM VI ÁP DỤNG
Áp dụng cho ai, bộ phận nào, trường hợp nào.

## 3. ĐỊNH NGHĨA & THUẬT NGỮ
Giải thích thuật ngữ chuyên môn.

## 4. VAI TRÒ & TRÁCH NHIỆM
Bảng: | Vai trò | Nhiệm vụ | Quyền hạn |

## 5. QUY TRÌNH THỰC HIỆN
Từng bước chi tiết (5.1, 5.2, 5.3...). Mỗi bước: Hành động — Ai làm — Input/Output — Thời gian.

## 6. CHECKLIST KIỂM TRA
Dạng - [ ] để in ra dùng trực tiếp. Ít nhất 10 mục.

## 7. KPI & TIÊU CHÍ ĐÁNH GIÁ
Bảng: | KPI | Mục tiêu | Cách đo | Tần suất |

## 8. XỬ LÝ NGOẠI LỆ
Tình huống bất thường và cách xử lý.

## 9. BIỂU MẪU & TÀI LIỆU LIÊN QUAN
Các form, template, tài liệu cần dùng.

## 10. LỊCH SỬ THAY ĐỔI
| Phiên bản | Ngày | Người thay đổi | Nội dung |
|-----------|------|----------------|----------|
| 1.0 | ${new Date().toLocaleDateString('vi-VN')} | ${fd.executor || 'AIFUN'} | Tạo mới |

Viết bằng tiếng Việt. Thực chiến, ngắn gọn, có thể dùng ngay.`;
    },
  },

  // ── SK-002: Content Factory ────────────────────────────────────────────────
  'content-factory': {
    skillId:       'content-factory',
    title:         'Content Factory',
    icon:          '📸',
    category:      'Marketing',
    color:         '#EC4899',
    desc:          'Biến 1 ý tưởng thành nội dung đa kênh: FB, YouTube, TikTok, Email, Zalo.',
    estimatedTime: '~3 phút',
    outputType:    'Content Package',

    fields: [
      {
        id: 'topic', label: 'Chủ đề / Ý tưởng *', type: 'text',
        placeholder: 'VD: 5 cách AI tiết kiệm 3 giờ làm việc mỗi ngày',
        required: true, span: 2
      },
      {
        id: 'brand', label: 'Thương hiệu *', type: 'text',
        placeholder: 'VD: AIFUN, Cửa hàng ABC...',
        required: true
      },
      {
        id: 'audience', label: 'Khách hàng mục tiêu *', type: 'text',
        placeholder: 'VD: Chủ SME 35-50 tuổi, doanh thu 1-10 tỷ/năm',
        required: true
      },
      {
        id: 'channels', label: 'Kênh đăng *', type: 'checkbox-group',
        options: ['Facebook', 'YouTube Script', 'TikTok', 'Email', 'Zalo OA'],
        required: true, span: 2
      },
      {
        id: 'objective', label: 'Mục tiêu nội dung *', type: 'select',
        options: ['Tăng nhận diện thương hiệu', 'Thu hút leads', 'Bán sản phẩm/dịch vụ', 'Giáo dục khách hàng', 'Tăng engagement'],
        required: true
      },
      {
        id: 'cta', label: 'CTA mong muốn', type: 'text',
        placeholder: 'VD: Đăng ký webinar, Nhắn tin tư vấn...',
        required: false
      },
      {
        id: 'tone', label: 'Tone of Voice', type: 'select',
        options: ['Chuyên nghiệp & Uy tín', 'Thân thiện & Gần gũi', 'Truyền cảm hứng', 'Thực chiến & Thẳng thắn', 'Hài hước & Vui'],
        required: false, defaultValue: 'Thực chiến & Thẳng thắn'
      },
    ],

    aiOutputSections: ['Facebook Post', 'YouTube Script', 'TikTok Caption', 'Email', 'Zalo OA', 'Content Calendar'],

    buildTitle(fd) {
      const d     = new Date().toLocaleDateString('vi-VN').replace(/\//g, '');
      const topic = (fd.topic || 'Content').substring(0, 25).replace(/\s+/g, '_');
      return `CONTENT_${topic}_${d}`;
    },

    buildPrompt(fd) {
      const channels = fd.channels || 'Facebook, YouTube, TikTok, Email, Zalo OA';
      return `Bạn là chuyên gia content marketing của AIFUN. Tạo content package đa kênh hoàn chỉnh, sẵn sàng đăng ngay.

THÔNG TIN:
- Chủ đề: ${fd.topic || ''}
- Thương hiệu: ${fd.brand || ''}
- Khách hàng mục tiêu: ${fd.audience || ''}
- Kênh đăng: ${channels}
- Mục tiêu: ${fd.objective || ''}
- CTA: ${fd.cta || 'Nhắn tin tư vấn'}
- Tone: ${fd.tone || 'Thực chiến & Thẳng thắn'}

## FACEBOOK POST
Hook mạnh + Nội dung 3-5 điểm + CTA + 5-10 hashtags. Độ dài 300-500 chữ. Dùng emoji.

## YOUTUBE SCRIPT
Hook 0-30s | Intro 30-60s | Nội dung chính 3-5 phần | Outro + CTA | YouTube Description 150 chữ.

## TIKTOK / REELS SCRIPT
Hook 3 giây đầu | Script 45-60 giây từng cảnh | Caption 100-150 chữ | 5-10 hashtags trending.

## EMAIL MARKETING
Subject line (3 phiên bản A/B/C) | Preview text 50-80 ký tự | Body: Greeting→Pain→Solution→CTA | CTA button text.

## ZALO OA MESSAGE
Tin nhắn 100-150 chữ, cá nhân, có emoji, kết thúc bằng CTA và link.

## CONTENT CALENDAR — 7 NGÀY
| Ngày | Kênh | Loại nội dung | Tiêu đề ngắn | Giờ đăng tối ưu |

Thương hiệu: ${fd.brand || ''} | Tone: ${fd.tone || ''} | Mục tiêu: ${fd.objective || ''}
Viết bằng tiếng Việt, phù hợp SME Việt Nam.`;
    },
  },

  // ── SK-003: Email Automation ───────────────────────────────────────────────
  'email-automation': {
    skillId:       'email-automation',
    title:         'Email Automation',
    icon:          '📧',
    category:      'Automation',
    color:         '#8B5CF6',
    desc:          'Thiết kế chuỗi email nurturing tự động, cá nhân hóa theo segment.',
    estimatedTime: '~3 phút',
    outputType:    'Email Sequence',

    fields: [
      {
        id: 'campaignType', label: 'Loại chiến dịch *', type: 'select',
        options: ['Onboarding (khách hàng mới)', 'Lead Nurturing (chưa chốt)', 'Upsell (khách cũ)', 'Re-engagement (khách bỏ)', 'Flash Sale / Promotion', 'Webinar Registration', 'Post-Webinar Follow-up'],
        required: true, span: 2
      },
      {
        id: 'brand', label: 'Thương hiệu *', type: 'text',
        placeholder: 'VD: AIFUN, ConnectAI...',
        required: true
      },
      {
        id: 'product', label: 'Sản phẩm / Dịch vụ *', type: 'text',
        placeholder: 'VD: Khóa học AI Business OS - 3 tháng',
        required: true
      },
      {
        id: 'audience', label: 'Đối tượng nhận email *', type: 'text',
        placeholder: 'VD: Chủ SME đã đăng ký webinar nhưng chưa mua',
        required: true, span: 2
      },
      {
        id: 'emailCount', label: 'Số email trong chuỗi *', type: 'select',
        options: ['3 emails (ngắn gọn)', '5 emails (tiêu chuẩn)', '7 emails (đầy đủ)', '10 emails (chuyên sâu)'],
        required: true
      },
      {
        id: 'finalGoal', label: 'Mục tiêu cuối chuỗi *', type: 'text',
        placeholder: 'VD: Chốt đăng ký khóa học 5,900,000đ',
        required: true
      },
      {
        id: 'tone', label: 'Giọng văn', type: 'select',
        options: ['Chuyên nghiệp & Tin tưởng', 'Gần gũi & Cá nhân', 'Khẩn cấp & Thúc đẩy', 'Giáo dục & Hữu ích'],
        required: false
      },
    ],

    aiOutputSections: ['Email 1 Chào mừng', 'Email 2 Giá trị', 'Email 3 Social Proof', 'Email 4+ Offer', 'Timing Schedule'],

    buildTitle(fd) {
      const d     = new Date().toLocaleDateString('vi-VN').replace(/\//g, '');
      const type  = (fd.campaignType || 'Email').split(' ')[0];
      const brand = (fd.brand || '').substring(0, 10).replace(/\s+/g, '');
      return `EMAIL_${type}_${brand}_${d}`;
    },

    buildPrompt(fd) {
      const count = parseInt((fd.emailCount || '5').match(/\d+/)?.[0]) || 5;
      return `Bạn là chuyên gia email marketing và automation của AIFUN. Thiết kế chuỗi email tự động hoàn chỉnh, tối ưu conversion.

THÔNG TIN:
- Loại chiến dịch: ${fd.campaignType || ''}
- Thương hiệu: ${fd.brand || ''}
- Sản phẩm/Dịch vụ: ${fd.product || ''}
- Đối tượng: ${fd.audience || ''}
- Số email: ${count}
- Mục tiêu cuối: ${fd.finalGoal || ''}
- Tone: ${fd.tone || 'Gần gũi & Cá nhân'}

${Array.from({length: count}, (_, i) => `
## EMAIL ${i + 1}${i === 0 ? ' — CHÀO MỪNG / HOOK' : i === count - 1 ? ' — CHỐT / CTA MẠNH' : ` — ${['GIÁ TRỊ & GIÁO DỤC','SOCIAL PROOF','XỬ LÝ TỪ CHỐI','KHAN HIẾM / URGENCY','NHẮC NHỞ'][i-1] || 'GIÁ TRỊ'}`}

Subject line:
A. [Benefit-focused]
B. [Curiosity-hook]
C. [Social proof]

Preview text: [50-80 ký tự]

Nội dung: [Greeting → Hook → Body → CTA]

CTA button: [Text]
Gửi: Ngày D+${i === 0 ? 0 : i * 2}`).join('\n')}

## TIMING SCHEDULE
| Email | Ngày gửi | Subject | Trigger | Ghi chú |

## AUTOMATION FLOW (Make / Zapier)
Sơ đồ đơn giản toàn chuỗi, điều kiện re-trigger.

Viết bằng tiếng Việt. Tone: ${fd.tone || 'Gần gũi & Cá nhân'}. Mục tiêu: ${fd.finalGoal || ''}.`;
    },
  },

  // ── SK-004: CRM AI Assistant ───────────────────────────────────────────────
  'crm-ai': {
    skillId:       'crm-ai',
    title:         'CRM AI Assistant',
    icon:          '💛',
    category:      'CRM',
    color:         '#F59E0B',
    desc:          'Phân tích lead, chấm điểm, đề xuất bước tiếp theo tối ưu tỷ lệ chốt.',
    estimatedTime: '~1 phút',
    outputType:    'CRM Report',

    fields: [
      {
        id: 'customerName', label: 'Tên khách hàng / Lead *', type: 'text',
        placeholder: 'VD: Anh Minh Tâm — Công ty Nội Thất ABC',
        required: true, span: 2
      },
      {
        id: 'industry', label: 'Ngành nghề *', type: 'text',
        placeholder: 'VD: Nội thất, Giáo dục, Thú y...',
        required: true
      },
      {
        id: 'companySize', label: 'Quy mô doanh nghiệp', type: 'select',
        options: ['Cá nhân / Hộ kinh doanh', 'SME (1-50 nhân viên)', 'Doanh nghiệp vừa (50-200)', 'Doanh nghiệp lớn (200+)'],
        required: false
      },
      {
        id: 'currentStage', label: 'Giai đoạn pipeline *', type: 'select',
        options: ['Lead mới (chưa liên lạc)', 'Đã liên lạc lần đầu', 'Đã gửi thông tin', 'Đang demo/tư vấn', 'Đang cân nhắc', 'Gần chốt'],
        required: true
      },
      {
        id: 'painPoints', label: 'Pain points khách hàng *', type: 'textarea',
        placeholder: 'Khách hàng đang gặp vấn đề gì? Muốn giải quyết điều gì?',
        required: true, span: 2, rows: 3
      },
      {
        id: 'budget', label: 'Ngân sách (nếu biết)', type: 'text',
        placeholder: 'VD: 5-10 triệu, chưa rõ...',
        required: false
      },
      {
        id: 'lastInteraction', label: 'Tương tác gần nhất', type: 'text',
        placeholder: 'VD: Hỏi giá qua Zalo 2 ngày trước...',
        required: false
      },
    ],

    aiOutputSections: ['Customer Profile', 'Lead Score', 'Next Best Action', 'Talking Points', 'Objection Handling', 'Proposed Offer'],

    buildTitle(fd) {
      const d    = new Date().toLocaleDateString('vi-VN').replace(/\//g, '');
      const name = (fd.customerName || 'Lead').substring(0, 20).replace(/\s+/g, '_');
      return `CRM_${name}_${d}`;
    },

    buildPrompt(fd) {
      return `Bạn là chuyên gia CRM và Sales của AIFUN. Phân tích khách hàng/lead và đưa ra kế hoạch bán hàng tối ưu.

THÔNG TIN:
- Tên: ${fd.customerName || ''}
- Ngành nghề: ${fd.industry || ''}
- Quy mô: ${fd.companySize || 'Chưa rõ'}
- Giai đoạn pipeline: ${fd.currentStage || ''}
- Pain points: ${fd.painPoints || ''}
- Ngân sách: ${fd.budget || 'Chưa rõ'}
- Tương tác gần nhất: ${fd.lastInteraction || 'Chưa có'}

## 1. CUSTOMER PROFILE
Tổng hợp profile. Phân tích: Tâm lý mua hàng, động lực, rào cản.

## 2. LEAD SCORE (thang 100)
| Tiêu chí | Điểm tối đa | Điểm đánh giá | Ghi chú |
|----------|-------------|---------------|---------|
| Mức độ cần thiết | 25 | ... | ... |
| Khả năng tài chính | 25 | ... | ... |
| Quyền ra quyết định | 20 | ... | ... |
| Thời gian mua | 15 | ... | ... |
| Mức độ engagement | 15 | ... | ... |
| TỔNG ĐIỂM | 100 | ... | Hot/Warm/Cold |

## 3. NEXT BEST ACTION (3 bước trong 24-48h)
Hành động 1: [Cụ thể — Kênh — Thời điểm]
Hành động 2: [...]
Hành động 3: [...]

## 4. TALKING POINTS (5 điểm khi gặp)
Phù hợp với pain point cụ thể của khách.

## 5. OBJECTION HANDLING
| Từ chối | Cách xử lý | Câu nói mẫu |
|---------|------------|-------------|

## 6. PROPOSED OFFER
Đề xuất gói phù hợp nhất. Tại sao đây là lựa chọn tốt nhất.

## 7. FOLLOW-UP TEMPLATE
Mẫu tin nhắn Zalo/email follow-up cho giai đoạn hiện tại.

Phân tích thực chiến, tập trung hành động cụ thể.`;
    },
  },

  // ── SK-005: Webinar Builder ────────────────────────────────────────────────
  'webinar-builder': {
    skillId:       'webinar-builder',
    title:         'Webinar Builder',
    icon:          '🎯',
    category:      'Education',
    color:         '#10B981',
    desc:          'Thiết kế webinar bán hàng A-Z: kịch bản, slide, CTA, follow-up email.',
    estimatedTime: '~4 phút',
    outputType:    'Webinar Kit',

    fields: [
      {
        id: 'webinarTitle', label: 'Tiêu đề webinar *', type: 'text',
        placeholder: 'VD: AI Business OS — Vận hành Doanh nghiệp Tự động 2026',
        required: true, span: 2
      },
      {
        id: 'brand', label: 'Thương hiệu *', type: 'text',
        placeholder: 'VD: AIFUN, ConnectAI...',
        required: true
      },
      {
        id: 'presenter', label: 'Tên diễn giả *', type: 'text',
        placeholder: 'VD: Diệp Thành Chung — CEO ConnectAI',
        required: true
      },
      {
        id: 'audience', label: 'Đối tượng tham dự *', type: 'text',
        placeholder: 'VD: Chủ SME 35-55 tuổi, doanh thu 2-20 tỷ/năm',
        required: true
      },
      {
        id: 'duration', label: 'Thời lượng *', type: 'select',
        options: ['60 phút', '90 phút', '120 phút', '150 phút', '180 phút'],
        required: true
      },
      {
        id: 'offer', label: 'Sản phẩm chốt (Offer) *', type: 'text',
        placeholder: 'VD: Khóa học AI Business OS — 5,900,000đ/người',
        required: true, span: 2
      },
      {
        id: 'keyPoints', label: 'Nội dung chính *', type: 'textarea',
        placeholder: '- AI giúp giảm 70% thao tác thủ công\n- Xây SOP chuẩn trong 30 phút\n- Tự động hóa CSKH',
        required: true, span: 2, rows: 4
      },
      {
        id: 'bonuses', label: 'Bonus / Quà tặng', type: 'text',
        placeholder: 'VD: Template SOP, 30 Prompts AI, Nhóm Zalo...',
        required: false, span: 2
      },
    ],

    aiOutputSections: ['Title & Hook', 'Agenda Chi tiết', 'MC Script', 'Slide Outline', 'Offer Presentation', 'Follow-up Emails'],

    buildTitle(fd) {
      const d     = new Date().toLocaleDateString('vi-VN').replace(/\//g, '');
      const title = (fd.webinarTitle || 'Webinar').substring(0, 25).replace(/\s+/g, '_');
      return `WEBINAR_${title}_${d}`;
    },

    buildPrompt(fd) {
      const dur = parseInt((fd.duration || '90').match(/\d+/)?.[0]) || 90;
      return `Bạn là chuyên gia thiết kế webinar bán hàng của AIFUN. Tạo Webinar Kit hoàn chỉnh, sẵn sàng triển khai.

THÔNG TIN:
- Tiêu đề: ${fd.webinarTitle || ''}
- Thương hiệu: ${fd.brand || ''}
- Diễn giả: ${fd.presenter || ''}
- Đối tượng: ${fd.audience || ''}
- Thời lượng: ${fd.duration || '90 phút'}
- Offer chốt: ${fd.offer || ''}
- Nội dung chính: ${fd.keyPoints || ''}
- Bonus: ${fd.bonuses || 'Chưa xác định'}

## 1. TITLE & HOOK
Tiêu đề chính: ${fd.webinarTitle || ''}
Tiêu đề phụ A/B/C: [kết quả / nỗi đau / con số cụ thể]
Hook mở đầu: [Câu đầu tiên gây chú ý ngay lập tức]

## 2. AGENDA CHI TIẾT (${dur} phút)
| Phút | Phần | Nội dung | Kỹ thuật |
|------|------|----------|----------|
| 0-10 | Opening | ... | ... |
| ... | ... | ... | ... |
| ${dur-20}-${dur} | Offer & Q&A | ... | ... |

## 3. MC SCRIPT — KỊCH BẢN CHI TIẾT
[0:00-10:00] OPENING: > [Script chi tiết]
[Từng phần theo agenda]: > [Script]
[${dur-20}:00-${dur}:00] CHỐT OFFER: > [Kịch bản chốt sale + xử lý từ chối]

## 4. SLIDE OUTLINE
| Slide # | Tiêu đề | Nội dung chính | Hình ảnh gợi ý |

## 5. OFFER PRESENTATION SCRIPT
Giá gốc → Giá ưu đãi | Stack value | Bonuses | Guarantee | Deadline/Urgency | CTA chốt đơn

## 6. Q&A — XỬ LÝ 5 CÂU HỎI THƯỜNG GẶP
| Câu hỏi | Cách trả lời |

## 7. EMAIL FOLLOW-UP (3 emails)
Email 1 (ngay sau): Subject + Nội dung
Email 2 (ngày hôm sau): Subject + Urgency
Email 3 (deadline cuối): Subject + Last chance

Offer: ${fd.offer || ''} | Diễn giả: ${fd.presenter || ''}`;
    },
  },

  // ── SK-006: Sales Script Generator ────────────────────────────────────────
  'sales-script': {
    skillId:       'sales-script',
    title:         'Sales Script Generator',
    icon:          '🏆',
    category:      'Sales',
    color:         '#EF4444',
    desc:          'Tạo kịch bản bán hàng hoàn chỉnh, xử lý từ chối và chốt sale.',
    estimatedTime: '~2 phút',
    outputType:    'Sales Script',

    fields: [
      {
        id: 'product', label: 'Sản phẩm / Dịch vụ *', type: 'text',
        placeholder: 'VD: Khóa học AI Business OS — 3 tháng thực chiến',
        required: true, span: 2
      },
      {
        id: 'industry', label: 'Ngành của khách hàng *', type: 'text',
        placeholder: 'VD: Nội thất, giáo dục, thú y...',
        required: true
      },
      {
        id: 'price', label: 'Giá bán *', type: 'text',
        placeholder: 'VD: 5,900,000đ/người',
        required: true
      },
      {
        id: 'targetCustomer', label: 'Đặc điểm khách hàng *', type: 'textarea',
        placeholder: 'Tuổi, vị trí, thu nhập, nỗi đau chính, mong muốn...',
        required: true, span: 2, rows: 3
      },
      {
        id: 'channel', label: 'Kênh bán hàng *', type: 'select',
        options: ['Zalo / Chat', 'Facebook Messenger', 'Gặp trực tiếp (offline)', 'Zoom / Video call', 'Điện thoại', 'Email'],
        required: true
      },
      {
        id: 'sellerRole', label: 'Vị trí người bán', type: 'select',
        options: ['CEO / Founder', 'Sales Manager', 'Nhân viên tư vấn', 'Telesales', 'Freelancer'],
        required: false
      },
      {
        id: 'mainObjection', label: 'Từ chối hay gặp nhất *', type: 'text',
        placeholder: 'VD: "Đắt quá", "Tôi chưa có thời gian"...',
        required: true, span: 2
      },
      {
        id: 'uniqueValue', label: 'Điểm khác biệt / USP', type: 'text',
        placeholder: 'VD: Học xong áp dụng ngay, hỗ trợ 1-1...',
        required: false, span: 2
      },
    ],

    aiOutputSections: ['Opening Script', 'Discovery Questions', 'Pain Identification', 'Solution Pitch', 'Offer Presentation', 'Objection Handling', 'Closing Script', 'Follow-up Messages'],

    buildTitle(fd) {
      const d       = new Date().toLocaleDateString('vi-VN').replace(/\//g, '');
      const product = (fd.product || 'Sales').substring(0, 20).replace(/\s+/g, '_');
      return `SALES_${product}_${d}`;
    },

    buildPrompt(fd) {
      return `Bạn là chuyên gia sales và chốt deal của AIFUN. Tạo kịch bản bán hàng hoàn chỉnh, thực chiến, áp dụng ngay được.

THÔNG TIN:
- Sản phẩm/Dịch vụ: ${fd.product || ''}
- Giá bán: ${fd.price || ''}
- Ngành khách hàng: ${fd.industry || ''}
- Khách hàng mục tiêu: ${fd.targetCustomer || ''}
- Kênh bán: ${fd.channel || 'Zalo / Chat'}
- Người bán: ${fd.sellerRole || 'Nhân viên tư vấn'}
- Từ chối hay gặp: ${fd.mainObjection || ''}
- USP: ${fd.uniqueValue || ''}

## 1. OPENING SCRIPT (kênh: ${fd.channel || 'Zalo'})
Lần 1 liên lạc (Cold): > "..."
Lần 2 Follow up: > "..."

## 2. DISCOVERY QUESTIONS — 7 CÂU HỎI KHÁM PHÁ
1. [Pain point]
2. [Urgency]
3. [Budget]
4. [Decision maker]
5. [Expectations]
6. [Timeline]
7. [Closing intent]

## 3. PAIN IDENTIFICATION
Cách khai thác và khuếch đại nỗi đau: > "..."

## 4. SOLUTION PITCH
Script giới thiệu sản phẩm (tập trung lợi ích, không phải tính năng): > "..."

## 5. OFFER PRESENTATION
Cách trình bày giá ${fd.price || ''} tự nhiên, không ngại: > "..."

## 6. OBJECTION HANDLING
Từ chối 1: "${fd.mainObjection || 'Đắt quá'}" > "..."
Từ chối 2: "Để tôi suy nghĩ thêm" > "..."
Từ chối 3: "Tôi bận chưa có thời gian" > "..."
Từ chối 4: "Tôi chưa cần ngay" > "..."
Từ chối 5: "Có thể rẻ hơn không?" > "..."

## 7. CLOSING SCRIPT — 3 CÁCH CHỐT
Alternative close: > "..."
Urgency close: > "..."
Summary close: > "..."

## 8. FOLLOW-UP MESSAGES
Sau 24h: > "..."
Sau 3 ngày: > "..."
Ngày 7 (cuối): > "..."

Sản phẩm: ${fd.product || ''} | Kênh: ${fd.channel || ''} | Người bán: ${fd.sellerRole || ''}
Viết bằng tiếng Việt, tự nhiên, phù hợp SME Việt Nam.`;
    },
  },

};

// ── Helpers ───────────────────────────────────────────────────────────────────
function getSkillForm(skillId) {
  if (SKILL_FORMS[skillId]) return SKILL_FORMS[skillId];
  const key = Object.keys(SKILL_FORMS).find(k => skillId.includes(k) || k.includes(skillId));
  return key ? SKILL_FORMS[key] : null;
}

function getAllSkillIds() {
  return Object.keys(SKILL_FORMS);
}
