/**
 * AIFUN OS v2 — skill-engine.js
 * Core engine: Form → GAS Backend → Google Docs → Result
 * Phụ thuộc: config.js, skill-forms.js (load trước)
 */

var SkillEngine = (function () {

  var _currentSkillId  = null;
  var _currentFormData = null;

  // ── Init: inject modal vào body ───────────────────────────────────────────
  function init() {
    if (document.getElementById('se-modal-container')) return;

    var el = document.createElement('div');
    el.id  = 'se-modal-container';
    el.innerHTML =
      '<div id="se-backdrop" onclick="SkillEngine.close()"></div>' +
      '<div id="se-modal" role="dialog" aria-modal="true">' +
        '<div class="se-modal-header">' +
          '<div class="se-modal-title-wrap">' +
            '<span id="se-modal-icon" class="se-modal-icon"></span>' +
            '<div>' +
              '<div id="se-modal-title" class="se-modal-title">Skill</div>' +
              '<div id="se-modal-subtitle" class="se-modal-subtitle"></div>' +
            '</div>' +
          '</div>' +
          '<button class="se-close-btn" onclick="SkillEngine.close()">✕</button>' +
        '</div>' +
        '<div class="se-steps">' +
          '<div class="se-step active" data-step="1"><span>1</span><small>Nhập liệu</small></div>' +
          '<div class="se-step-line"></div>' +
          '<div class="se-step" data-step="2"><span>2</span><small>AI xử lý</small></div>' +
          '<div class="se-step-line"></div>' +
          '<div class="se-step" data-step="3"><span>3</span><small>Tài liệu</small></div>' +
        '</div>' +
        '<div id="se-modal-body" class="se-modal-body"></div>' +
      '</div>';

    document.body.appendChild(el);

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') close();
    });
  }

  // ── Launch skill ──────────────────────────────────────────────────────────
  function launch(skillIdRaw) {
    init();

    var skillId = normalizeId(skillIdRaw);
    var form    = getSkillForm(skillId);

    if (!form) {
      _showToast('⚠️ Skill "' + skillIdRaw + '" chưa được cấu hình.', 'warn');
      return;
    }

    _currentSkillId  = skillId;
    _currentFormData = null;

    document.getElementById('se-modal-icon').textContent     = form.icon;
    document.getElementById('se-modal-title').textContent    = form.title;
    document.getElementById('se-modal-subtitle').textContent =
      form.category + ' · ⏱ ' + form.estimatedTime + ' · 📄 ' + form.outputType;

    _renderForm(form);
    _openModal();
    _setStep(1);
  }

  // ── Step 1: Render form ───────────────────────────────────────────────────
  function _renderForm(form) {
    var html = '<form id="se-form" onsubmit="SkillEngine._submit(event)" novalidate>' +
               '<div class="se-field-grid">';

    form.fields.forEach(function (f) {
      var cls = f.span === 2 ? 'se-field se-field-full' : 'se-field';
      html += '<div class="' + cls + '">' + _renderField(f) + '</div>';
    });

    html += '</div>' +
            '<div class="se-form-actions">' +
              '<button type="button" class="se-btn se-btn-ghost" onclick="SkillEngine.close()">Huỷ</button>' +
              '<button type="submit" class="se-btn se-btn-primary">🚀 Tạo tài liệu với AI</button>' +
            '</div>' +
            '</form>';

    document.getElementById('se-modal-body').innerHTML = html;

    document.querySelectorAll('#se-form .se-checkbox-group input[type=checkbox]')
      .forEach(function (cb) {
        cb.addEventListener('change', function () {
          _syncCheckbox(cb.closest('.se-field'));
        });
      });
  }

  // ── Render một field ──────────────────────────────────────────────────────
  function _renderField(f) {
    var req   = f.required ? 'required' : '';
    var label = '<label for="se-' + f.id + '" class="se-label">' + f.label + '</label>';

    if (f.type === 'text') {
      return label + '<input type="text" id="se-' + f.id + '" name="' + f.id + '" class="se-input" ' +
             'placeholder="' + (f.placeholder || '') + '" ' + req + '>';
    }

    if (f.type === 'textarea') {
      return label + '<textarea id="se-' + f.id + '" name="' + f.id + '" class="se-textarea" ' +
             'placeholder="' + (f.placeholder || '') + '" rows="' + (f.rows || 3) + '" ' + req + '></textarea>';
    }

    if (f.type === 'select') {
      var opts = '<option value="">— Chọn —</option>';
      f.options.forEach(function (o) {
        opts += '<option value="' + o + '"' + (f.defaultValue === o ? ' selected' : '') + '>' + o + '</option>';
      });
      return label + '<select id="se-' + f.id + '" name="' + f.id + '" class="se-select" ' + req + '>' + opts + '</select>';
    }

    if (f.type === 'checkbox-group') {
      var checks = '';
      f.options.forEach(function (o) {
        checks += '<label class="se-check-label"><input type="checkbox" class="se-checkbox" value="' + o + '"> ' + o + '</label>';
      });
      return label +
             '<div class="se-checkbox-group">' + checks + '</div>' +
             '<input type="hidden" id="se-' + f.id + '" name="' + f.id + '" ' + req + '>';
    }

    return label + '<input type="text" id="se-' + f.id + '" name="' + f.id + '" class="se-input" ' +
           'placeholder="' + (f.placeholder || '') + '" ' + req + '>';
  }

  // ── Sync checkbox → hidden ────────────────────────────────────────────────
  function _syncCheckbox(fieldEl) {
    var hidden  = fieldEl.querySelector('input[type=hidden]');
    var checked = fieldEl.querySelectorAll('input[type=checkbox]:checked');
    var vals    = [];
    checked.forEach(function (c) { vals.push(c.value); });
    hidden.value = vals.join(', ');
  }

  // ── Form submit ───────────────────────────────────────────────────────────
  function _submit(e) {
    e.preventDefault();

    var form = document.getElementById('se-form');
    if (!_validate(form)) return;

    var fd  = new FormData(form);
    _currentFormData = {};
    fd.forEach(function (v, k) { _currentFormData[k] = v; });

    _renderLoading();
    _setStep(2);

    _callGAS(_currentSkillId, _currentFormData)
      .then(function (result) {
        _renderResult(result);
        _setStep(3);
      })
      .catch(function (err) {
        _renderError(err.message || 'Lỗi không xác định. Vui lòng thử lại.');
      });
  }

  // ── Validate ──────────────────────────────────────────────────────────────
  function _validate(form) {
    var valid = true;
    form.querySelectorAll('[required]').forEach(function (el) {
      el.classList.remove('se-input-error');
      if (!el.value.trim()) {
        el.classList.add('se-input-error');
        valid = false;
      }
    });
    if (!valid) {
      var first = form.querySelector('.se-input-error');
      if (first) first.focus();
      _showFormError('Vui lòng điền đầy đủ các trường bắt buộc (*)');
    }
    return valid;
  }

  // ── Step 2: Loading ───────────────────────────────────────────────────────
  function _renderLoading() {
    var form  = SKILL_FORMS[_currentSkillId];
    var steps = form ? form.aiOutputSections : ['Phân tích', 'Tạo nội dung', 'Tạo tài liệu'];

    var stepsHtml = '';
    steps.forEach(function (s, i) {
      stepsHtml += '<div class="se-ls-item" id="se-ls-' + i + '">' +
                   '<span class="se-ls-icon">⏳</span><span>' + s + '</span></div>';
    });

    document.getElementById('se-modal-body').innerHTML =
      '<div class="se-loading">' +
        '<div class="se-spinner"></div>' +
        '<div class="se-loading-title">AI đang xử lý…</div>' +
        '<div class="se-loading-sub">Đang tạo ' + (form ? form.outputType : 'tài liệu') +
        '. Vui lòng chờ khoảng ' + (form ? form.estimatedTime : '2-3 phút') + '.</div>' +
        '<div class="se-loading-steps">' + stepsHtml + '</div>' +
        '<div class="se-loading-note">💡 AI đang gọi Claude để tạo nội dung &amp; Google Docs cho bạn</div>' +
      '</div>';

    var interval = AIFUN_CONFIG.requestTimeout / steps.length * 0.3;
    steps.forEach(function (_, i) {
      setTimeout(function () {
        var el = document.getElementById('se-ls-' + i);
        if (el) { el.querySelector('.se-ls-icon').textContent = '🔄'; el.classList.add('active'); }
        if (i > 0) {
          var prev = document.getElementById('se-ls-' + (i - 1));
          if (prev) { prev.querySelector('.se-ls-icon').textContent = '✅'; prev.classList.add('done'); }
        }
      }, i * interval);
    });
  }

  // ── Step 3: Result ────────────────────────────────────────────────────────
  function _renderResult(result) {
    var fileName  = result.fileName  || 'AIFUN_Document';
    var docUrl    = result.docUrl    || '#';
    var pdfUrl    = result.pdfUrl    || '';
    var wordUrl   = result.wordUrl   || '';
    var content   = result.content   || '';
    var docId     = result.docId     || '—';
    var createdAt = result.createdAt || new Date().toLocaleString('vi-VN');

    var preview = content.substring(0, 800).replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>');
    if (content.length > 800) preview += '…';

    var actions = '<a href="' + docUrl + '" target="_blank" rel="noopener" class="se-btn se-btn-primary">📄 Xem Google Docs</a>';
    if (pdfUrl)  actions += '<a href="' + pdfUrl  + '" target="_blank" class="se-btn se-btn-secondary">⬇️ Tải PDF</a>';
    if (wordUrl) actions += '<a href="' + wordUrl + '" target="_blank" class="se-btn se-btn-secondary">📝 Tải Word</a>';
    actions += '<button class="se-btn se-btn-ghost" onclick="SkillEngine._copy()">📋 Sao chép</button>';

    document.getElementById('se-modal-body').innerHTML =
      '<div class="se-result">' +
        '<div class="se-result-success">' +
          '<div class="se-result-check">✅</div>' +
          '<div class="se-result-msg">Tài liệu đã được tạo thành công!</div>' +
          '<div class="se-result-file">' + fileName + '</div>' +
        '</div>' +
        '<div class="se-result-actions">' + actions + '</div>' +
        '<div class="se-result-preview">' +
          '<div class="se-result-preview-label">📝 Xem trước nội dung</div>' +
          '<div class="se-result-preview-body">' + (preview || '(Không có preview)') + '</div>' +
        '</div>' +
        '<div class="se-result-meta">' +
          '<span>📅 ' + createdAt + '</span>' +
          '<span>🔗 ID: ' + docId + '</span>' +
        '</div>' +
        '<div class="se-result-bottom">' +
          '<button class="se-btn se-btn-ghost" onclick="SkillEngine._again()">➕ Tạo tài liệu mới</button>' +
          '<button class="se-btn se-btn-ghost" onclick="SkillEngine.close()">Đóng</button>' +
        '</div>' +
      '</div>';

    window.__seContent = content;
    _showToast('✅ Tài liệu đã được lưu vào Google Drive!', 'success');
  }

  // ── Error ─────────────────────────────────────────────────────────────────
  function _renderError(msg) {
    document.getElementById('se-modal-body').innerHTML =
      '<div class="se-error">' +
        '<div class="se-error-icon">❌</div>' +
        '<div class="se-error-title">Có lỗi xảy ra</div>' +
        '<div class="se-error-msg">' + msg + '</div>' +
        '<div class="se-result-bottom">' +
          '<button class="se-btn se-btn-primary" onclick="SkillEngine._retry()">🔄 Thử lại</button>' +
          '<button class="se-btn se-btn-ghost" onclick="SkillEngine.close()">Đóng</button>' +
        '</div>' +
      '</div>';
    _setStep(1);
  }

  // ── Call Google Apps Script ───────────────────────────────────────────────
  function _callGAS(skillId, formData) {
    var url = AIFUN_CONFIG.gasWebAppUrl;

    if (!url || url.indexOf('YOUR_') !== -1) {
      return Promise.reject(new Error('GAS URL chưa được cấu hình trong config.js'));
    }

    var skillForm = SKILL_FORMS[skillId] || null;

    var prompt = skillForm && skillForm.buildPrompt
      ? skillForm.buildPrompt(formData)
      : _genericPrompt(skillId, formData);

    var title = skillForm && skillForm.buildTitle
      ? skillForm.buildTitle(formData)
      : skillId + '_' + new Date().toISOString().slice(0, 10);

    var payload = {
      action:        'generateDocument',
      skillId:       skillId,
      prompt:        prompt,
      title:         title,
      formData:      formData,
      provider:      AIFUN_CONFIG.defaultProvider,
      folderId:      AIFUN_CONFIG.driveFolderId,
      spreadsheetId: AIFUN_CONFIG.spreadsheetId,
      user:          _getUser(),
      timestamp:     new Date().toISOString(),
    };

    var controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timeoutId  = null;

    if (controller) {
      timeoutId = setTimeout(function () { controller.abort(); }, AIFUN_CONFIG.requestTimeout);
    }

    var fetchOpts = {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(payload),
    };
    if (controller) fetchOpts.signal = controller.signal;

    return fetch(url, fetchOpts)
      .then(function (res) {
        if (timeoutId) clearTimeout(timeoutId);
        if (!res.ok) throw new Error('HTTP ' + res.status + ': ' + res.statusText);
        return res.json();
      })
      .then(function (data) {
        if (data.error) throw new Error(data.error);
        return data;
      });
  }

  // ── Helpers ───────────────────────────────────────────────────────────────
  function _getUser() {
    try { return localStorage.getItem('aifun_user') || 'anonymous'; } catch(e) { return 'anonymous'; }
  }

  function normalizeId(raw) {
    return (raw || '').toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
  }

  function _genericPrompt(skillId, formData) {
    var lines = Object.keys(formData)
      .filter(function (k) { return formData[k] && ('' + formData[k]).trim(); })
      .map(function (k) { return '- ' + k + ': ' + formData[k]; })
      .join('\n');
    return 'Bạn là chuyên gia của AIFUN. Tạo tài liệu cho skill "' + skillId + '":\n\n' + lines + '\n\nViết bằng tiếng Việt, có cấu trúc rõ ràng.';
  }

  function _openModal() {
    document.getElementById('se-modal-container').classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  function close() {
    var el = document.getElementById('se-modal-container');
    if (el) el.classList.remove('active');
    document.body.style.overflow = '';
    _currentSkillId  = null;
    _currentFormData = null;
  }

  function _setStep(n) {
    document.querySelectorAll('.se-step').forEach(function (el) {
      var s = parseInt(el.getAttribute('data-step'));
      el.classList.toggle('active',    s === n);
      el.classList.toggle('completed', s  <  n);
    });
    document.querySelectorAll('.se-step-line').forEach(function (el, i) {
      el.classList.toggle('completed', i < n - 1);
    });
  }

  function _showFormError(msg) {
    var el = document.getElementById('se-form-error');
    if (!el) {
      el = document.createElement('div');
      el.id        = 'se-form-error';
      el.className = 'se-form-error';
      var form = document.getElementById('se-form');
      if (form) form.prepend(el);
    }
    el.textContent   = msg;
    el.style.display = 'block';
  }

  function _showToast(msg, type) {
    if (typeof window.showToast === 'function') { window.showToast(msg, type); return; }

    var id    = 'se-toast';
    var toast = document.getElementById(id);
    if (!toast) {
      toast = document.createElement('div');
      toast.id        = id;
      toast.className = 'se-toast';
      document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.className   = 'se-toast se-toast-' + (type || 'info') + ' show';
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { toast.classList.remove('show'); }, 3500);
  }

  function _copy() {
    var text = window.__seContent || '';
    if (!text) { _showToast('Không có nội dung để sao chép', 'warn'); return; }
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).then(function () { _showToast('✅ Đã sao chép!', 'success'); });
    } else {
      var ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      _showToast('✅ Đã sao chép!', 'success');
    }
  }

  function _again() {
    var form = SKILL_FORMS[_currentSkillId];
    if (form) { _renderForm(form); _setStep(1); }
    else close();
  }

  function _retry() {
    var form = SKILL_FORMS[_currentSkillId];
    if (!form) { close(); return; }
    _renderForm(form);
    _setStep(1);
    if (_currentFormData) {
      Object.keys(_currentFormData).forEach(function (k) {
        var el = document.getElementById('se-' + k);
        if (el) el.value = _currentFormData[k];
      });
    }
  }

  // ── Public API ────────────────────────────────────────────────────────────
  return {
    init:    init,
    launch:  launch,
    close:   close,
    _submit: _submit,
    _copy:   _copy,
    _again:  _again,
    _retry:  _retry,
  };

})();

window.SkillEngine = SkillEngine;

// Auto-init + intercept data-skill-launch clicks
document.addEventListener('DOMContentLoaded', function () {
  SkillEngine.init();

  document.addEventListener('click', function (e) {
    var btn = e.target.closest('[data-skill-launch]');
    if (!btn) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    var skillId = btn.getAttribute('data-skill-id') ||
                  (btn.closest('[data-skill-id]') && btn.closest('[data-skill-id]').getAttribute('data-skill-id'));
    if (skillId) SkillEngine.launch(skillId);
  }, true);
});
